
from patient_base import PatientBase


class Patient(PatientBase):
    def __init__(self, name, time):
        super().__init__(name, time)
    """
        Modify class Patient here if needed
    """
