public class Patient extends PatientBase {

    public Patient(String name, String time) {
        super(name, time);
    }

    @Override
    public int compareTo(PatientBase o) {
        /* Add your code here! */
        return 0;
    }

    /* Add any extra functions below */
}
