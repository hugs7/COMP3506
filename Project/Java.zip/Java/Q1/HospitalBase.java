public abstract class HospitalBase implements Iterable<PatientBase> {

    public abstract boolean addPatient(PatientBase patient);
}
